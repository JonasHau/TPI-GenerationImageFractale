var searchData=
[
  ['main_24',['Main',['../class_generation_image_fractale_1_1_main.html',1,'GenerationImageFractale.Main'],['../class_generation_image_fractale_1_1_main.html#ac758046d7ca5c40b4b5da7827d4e5f26',1,'GenerationImageFractale.Main.Main()']]],
  ['mandelbrot_25',['Mandelbrot',['../class_generation_image_fractale_1_1_mandelbrot.html',1,'GenerationImageFractale.Mandelbrot'],['../class_generation_image_fractale_1_1_mandelbrot.html#aa907748c99205f6abb52498a585dc120',1,'GenerationImageFractale.Mandelbrot.Mandelbrot()']]]
];
