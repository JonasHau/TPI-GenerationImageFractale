var searchData=
[
  ['generatefractal_59',['GenerateFractal',['../class_generation_image_fractale_1_1_fractal_manager.html#aae22c23eee3662229857eb462189e04b',1,'GenerationImageFractale::FractalManager']]],
  ['gethistory_60',['GetHistory',['../class_generation_image_fractale_1_1_query_builder.html#a0da977dd6b4bf3cf07e18147b323913e',1,'GenerationImageFractale::QueryBuilder']]]
];
