var searchData=
[
  ['savefractal_31',['SaveFractal',['../class_generation_image_fractale_1_1_query_builder.html#aff2881588780b8a647a29ca7e7a60c80',1,'GenerationImageFractale::QueryBuilder']]],
  ['select_32',['Select',['../class_generation_image_fractale_1_1_query_executor.html#a532f0192af93045d3227d6dda9dba6de',1,'GenerationImageFractale::QueryExecutor']]]
];
