var searchData=
[
  ['render_68',['Render',['../class_generation_image_fractale_1_1_fractal.html#a01d1522077f27057e67ac5f7db603a08',1,'GenerationImageFractale.Fractal.Render()'],['../class_generation_image_fractale_1_1_julia.html#a4d2da68cacf3a92b64ed9af2d8fc9945',1,'GenerationImageFractale.Julia.Render()'],['../class_generation_image_fractale_1_1_mandelbrot.html#a144610511e09bfeafcfce0f96e53194a',1,'GenerationImageFractale.Mandelbrot.Render()']]]
];
